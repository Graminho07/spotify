import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>This is Justin Bieber</Text>
      <Image source={require('./justin_foto.png')} style={styles.image} />
      <Image source={require('./play_spotify.png')} style={styles.spotifyImage} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0E372F',
    paddingTop: Constants.statusBarHeight,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'gray',
    marginTop: 10,
    alignSelf: 'center',
  },
  image: {
    flex: 1,
    width: '90%',
    height: '90%',
    resizeMode: 'contain',
    marginTop: 30,
  },
  spotifyImage: {
    width: 310,
    height: 200,
    resizeMode: 'contain',
    marginTop: 20,
  },
});
